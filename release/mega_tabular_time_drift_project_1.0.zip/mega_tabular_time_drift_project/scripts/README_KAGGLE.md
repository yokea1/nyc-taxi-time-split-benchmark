# Kaggle datasets note
These scripts rely on the **Kaggle CLI**. Set it up once:
1) Install: `pip install kaggle`
2) Place API token at `~/.kaggle/kaggle.json` (from your Kaggle Account settings)
3) Accept competition rules if required (e.g., IEEE-CIS Fraud).

Then run the download scripts.
